# miniNodeServer
minimum Node Server with SQLite
